def hipsterfy(word)
    vowels = "aeiou"
    i = word.length - 1
    while i >= 0
    if vowels.include?(word[i])
    return word[0...i] + word[i + 1..-1] 
    end
    i -= 1
    end
word
end

def vowel_counts(string)
    hash1 = Hash.new(0)
    vowels = "aeiou"
    string.each_char do |ele|
        if vowels.include?(ele.downcase)
            hash1[ele.downcase] += 1
        end
    end
    hash1
end

def caesar_cipher(message, n)
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    string1 = message.split("").map do |ele|
        if alphabet.include?(ele)
        oldindex = alphabet.index(ele)
        alphabet[(oldindex + n) % 26]
        else
            ele
        end
    end
    string1.join("")
end
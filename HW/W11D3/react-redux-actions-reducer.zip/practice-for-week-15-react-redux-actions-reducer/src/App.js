import './App.css';

function App() {
  return (
    <div>Hello from App!</div>
  );
}

export default App;
